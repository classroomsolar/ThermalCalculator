#!/usr/bin/env python3
"""Independent mathematical cross-check; NOT IEC product/site conformity certificate.
No source-module imports into Python oracle. JS adapters imported only for comparison.
"""
from __future__ import annotations
import hashlib,json, math, pathlib, random, subprocess, datetime, statistics, csv
ROOT=pathlib.Path('/mnt/data/cts_gate_20261026')
SRC=ROOT/'01_Private_Site_v3.6.2_Source'
PUB=ROOT/'public'
rng=random.Random(20261026)
def iec_oracle(x):
 n=x['conductor_count']; r=x['rac_at_limit_ohm_m']; wd=x['dielectric_w_m']
 t1,t2,t3,t4=(x[f't{i}_km_w'] for i in range(1,5))
 l1,l2=x['lambda1'],x['lambda2']
 # Independently expanded terms with explicit per-core heat streams, not an engine call
 qc=r * (t1+n*(1+l1)*t2+n*(1+l1+l2)*t3+n*(1+l1+l2)*t4)
 qd=wd*(t1/2+n*t2+n*t3+n*t4)
 head=x['limit_c']-x['ambient_c']-qd
 if head<=0:return None
 amp=math.sqrt(head/qc)
 at=x['ambient_c']+qc*x['load_a']**2+qd
 return dict(ampacity_a=amp,temperature_at_load_c=at,conductor_loss_path_km_w=qc/r,dielectric_loss_path_km_w=qd/wd if wd else t1/2+n*(t2+t3+t4))
def t1_oracle(x):return x['insulation_rho']*math.log(x['insulation_od_m']/x['conductor_diameter_m'])/(2*math.pi)
def t3_oracle(x):return x['jacket_rho']*math.log(x['cable_od_m']/x['sheath_mean_diameter_m'])/(2*math.pi)
def field_oracle(rows, tol):
 residuals=[b-a for a,b in rows]
 return dict(mae_c=sum(map(abs,residuals))/len(residuals),rmse_c=math.sqrt(sum(v*v for v in residuals)/len(residuals)),max_absolute_error_c=max(map(abs,residuals)))
samples=[]
for i in range(300):
 n=rng.randint(1,3)
 x=dict(conductor_count=n,ambient_c=rng.uniform(8,36),limit_c=rng.uniform(67,120),rac_at_limit_ohm_m=rng.uniform(.000015,.00018),dielectric_w_m=rng.uniform(0,.8),t1_km_w=rng.uniform(.04,.4),t2_km_w=rng.uniform(0,.2),t3_km_w=rng.uniform(0,.22),t4_km_w=rng.uniform(.4,2),lambda1=rng.uniform(0,.5),lambda2=rng.uniform(0,.45),load_a=rng.uniform(100,850),cable_source='independent numerical fixture',environment_source='independent numerical fixture')
 samples.append(dict(method='iec',input=x))
for i in range(120):
 dc=rng.uniform(.009,.037);di=dc*rng.uniform(1.08,1.65);sheath=di*rng.uniform(1.01,1.1);out=sheath*rng.uniform(1.05,1.25)
 st=dict(thermal_model='GEOMETRY',system='DC',ac_model='MANUAL',dielectric_model='MANUAL',conductor_diameter_m=dc,insulation_od_m=di,sheath_mean_diameter_m=sheath,insulation_rho=rng.uniform(2.5,5),jacket_rho=rng.uniform(2.5,5),t2_km_w=0)
 samples.append(dict(method='construction',input=dict(cable_od_m=out),settings=st))
for i in range(120):
 pairs=[[rng.uniform(-5,110),rng.uniform(-5,110)] for _ in range(rng.randint(1,60))]
 rows=[{'name':f'Sensor {j+1}','channel':'CONDUCTOR','measured_c':a,'predicted_c':b} for j,(a,b) in enumerate(pairs)]
 options=dict(verified=True,source='independent synthetic pairs',sensor_basis='matched synthetic pairs',tolerance_c=4)
 samples.append(dict(method='measurement',rows=rows,options=options))
# No user data is placed into these hypothetical fixtures.
js=r'''import {readFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
const original=process.argv[1],publicRoot=process.argv[2];
const oI=await import(pathToFileURL(original+'/lib/iec60287-loss-audit.mjs').href);
const oW=await import(pathToFileURL(original+'/lib/workbook-models.mjs').href);
const pI=await import(pathToFileURL(publicRoot+'/core/original-lib/iec60287-loss-audit.mjs').href);
const pW=await import(pathToFileURL(publicRoot+'/core/original-lib/workbook-models.mjs').href);
const samples=JSON.parse(readFileSync(0,'utf8'));
function solve(f,s){if(s.method==='iec')return f.i.iec60287LossAudit(s.input);if(s.method==='construction')return f.w.constructionModel(s.input,s.settings);return f.w.fieldValidation(s.rows,s.options);}
const old={i:oI,w:oW},pub={i:pI,w:pW};
process.stdout.write(JSON.stringify(samples.map(x=>({original:solve(old,x),public:solve(pub,x)}))));'''
proc=subprocess.run(['node','--input-type=module','-e',js,str(SRC),str(PUB)],input=json.dumps(samples),text=True,capture_output=True,timeout=80)
if proc.returncode:raise SystemExit('JS fixture runner failed: '+proc.stderr[:2000])
actual=json.loads(proc.stdout)
entries=[];passes=0;fails=0;by_method={}; max_deviation={}
def approx(a,b):return math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-8)
for i,(case,row) in enumerate(zip(samples,actual,strict=True)):
 meth=case['method'];source=row['original'];web=row['public'];exp={};keys=[]
 if meth=='iec':
  exp=iec_oracle(case['input']);keys=list(exp)
 elif meth=='construction':
  s=case['settings'];x=case['input'];exp={'t1_km_w':t1_oracle(s),'t3_km_w':t3_oracle(s|x)}
 elif meth=='measurement':
  exp=field_oracle([[v['measured_c'],v['predicted_c']] for v in case['rows']],case['options']['tolerance_c']);keys=list(exp)
 for version,val in [('original',source),('public',web)]:
  for key,oracle in exp.items():
   if meth=='construction': got=val.get('settings',{}).get(key)
   else: got=val.get(key)
   deviation=abs(got-oracle) if isinstance(got,(int,float)) else None
   ok=isinstance(got,(int,float)) and approx(got,oracle)
   if not ok:fails+=1
   else:passes+=1
   k=meth+'-'+key;max_deviation[k]=max(max_deviation.get(k,0),deviation or 0)
   if not ok:entries.append(dict(index=i,method=meth,version=version,quantity=key,observed=got,independent=oracle,absolute_error=deviation))
 by_method[meth]=by_method.get(meth,0)+1
 if source!=web:
  fails+=1;entries.append(dict(index=i,method=meth,issue='original-vs-public differs',original=str(source)[:200],public=str(web)[:200]))
report={'report_version':1,'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixture_seed':20261026,'independent_fixture_count':len(samples),'method_case_counts':by_method,'numerical_component_assertions_passed':passes,'failed_assertions':fails,'failure_samples':entries[:25],'maximum_abs_deviation':max_deviation,'scope':'Independent Python re-derivations of supplied-loss IEC 60287 AC equation, concentric single-core thermal T1/T3 and sensor error statistics. Original Node source compared with public-hosted matching JS source files. Not independent manufacturer tests, measurement calibration, full standards engineering certification, or React production build. All fixtures hypothetical and not customer cable input.','iec_reference':'https://webstore.iec.ch/en/publication/68118','thermal_reference':'https://webstore.iec.ch/en/publication/68134','status':'PASS' if fails==0 else 'FAIL'}
(ROOT/'independent_numerical_results.json').write_text(json.dumps(report,indent=2)+'\n')
(ROOT/'independent_numerical_fixtures.json').write_text(json.dumps(samples,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('maximum_abs_deviation','failure_samples')},indent=2))
if fails:raise SystemExit(1)
