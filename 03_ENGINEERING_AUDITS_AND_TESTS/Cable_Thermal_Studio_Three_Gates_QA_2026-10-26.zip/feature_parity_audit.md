# Original application versus public website — feature parity audit

**Full feature parity:** NOT VERIFIED. Source/published presence is not functional equivalence.

| Feature | Original source | Public UI | Public source engine | Result |
|---|---|---|---|---|
| Continuous rating and conductor temperature | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| Emergency transient and rating | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| 24-hour cyclic loading | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| IEC supplied-loss equation audit | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| 2-D soil field and dryout | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| Mesh and domain independence | Yes | Not detected | Present | PARTIAL / NOT EQUIVALENT |
| Physical coupled buried circuits | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| Heterogeneous multicore/direct/duct network | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| 3×3 duct position optimization | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| Source-gated verified T4 | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| Route bottleneck | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| Sensitivity sweep | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| Inverse thermal design | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| Scenario comparison editor | Yes | Not detected | Present | PARTIAL / NOT EQUIVALENT |
| Harmonic conductor heating | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| Robust environmental envelope | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| Manufacturer condition matched benchmark | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| Field sensor validation | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| Physical cable candidate/set ranking | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| Three-way code table/manufacturer/thermal rating | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| Source-aware cable library and custom cables | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| 93 audited Master Database browse | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| Source-workbook structural coverage | Yes | Not detected | Present | PARTIAL / NOT EQUIVALENT |
| Multiple-device data backup and recovery | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| XLSX/CSV/JSON user exports | Yes | Detected | Present | UI PRESENT / ENGINE RETAINED |
| Printable engineering reports | Yes | Detected | N/A | UI PRESENT / ENGINE RETAINED |
| Physical cable geometry full editor | Yes | Not detected | N/A | ORIGINAL ONLY / NOT EXPOSED |
| Advanced original-case schema v2/v3 roundtrip | Yes | Not detected | Present | PARTIAL / NOT EQUIVALENT |
| Original React SSR and client routes | Yes | Not detected | N/A | ORIGINAL ONLY / NOT EXPOSED |

## Highest-priority gaps and scope boundaries

- **24-hour cyclic loading:** Public advanced page uses a fixed reference profile; original editor has custom profiles. (UI marker: True).
- **2-D soil field and dryout:** Original has rectangular zones and mesh/domain diagnostics; public advanced editor narrower. (UI marker: True).
- **Mesh and domain independence:** No evidence of a complete dedicated public input/output editor. (UI marker: False).
- **Physical coupled buried circuits:** Heterogeneous public UI is limited to six cables; original models allow larger layouts. (UI marker: True).
- **Scenario comparison editor:** Original has user-defined per-scenario editor, public has route/sensitivity/optimize. (UI marker: False).
- **Physical cable candidate/set ranking:** Public UI now executes the original ranking engine and presents all trial rows, but original ranked-candidate-to-study handoff is not yet demonstrated. (UI marker: True).
- **Three-way code table/manufacturer/thermal rating:** Public UI now collects the source fields and displays three-way results; full original-report and case dependency equivalence remains unverified. (UI marker: True).
- **Source-workbook structural coverage:** Workbook listing not equal to every formula executing. (UI marker: False).
- **Multiple-device data backup and recovery:** Browser-local only; no remote cloud storage. (UI marker: True).
- **Printable engineering reports:** Public report functionality per module; no proof of identical original React report output. (UI marker: True).
- **Physical cable geometry full editor:** Public advanced page uses simpler assumptions; full editor not equivalent. (UI marker: False).
- **Advanced original-case schema v2/v3 roundtrip:** Unified public backups have different schema; cross-import to original React not demonstrated. (UI marker: False).
- **Original React SSR and client routes:** Public website is static Wix, not compiled original React. (UI marker: False).

## Interpretation

The original React app has not been compiled here. No amount of file names, imports, or static feature labels can replace real original-versus-public browser acceptance. This audit gives reproducible exact-source evidence for prioritizing work without assuming feature parity.
