from pathlib import Path
from playwright.sync_api import sync_playwright
import base64,re,json,hashlib
root=Path('/mnt/data/cts_gate_20261026/public')
imported={}
def module(p):
 p=p.resolve()
 key='cts:/'+str(p.relative_to(root))
 if key in imported:return key
 imported[key]='pending'
 src=p.read_text()
 def repl(m):
  target=(p.parent/m.group(3)).resolve()
  if root not in target.parents:raise ValueError('Path escape '+str(target))
  return m.group(1)+repr(module(target))
 src=re.sub(r'(\b(?:from\s*|import\s*))([\'\"])(\.\/[^\'\"]+)\2',repl,src)
 imported[key]='data:text/javascript;base64,'+base64.b64encode(src.encode()).decode()
 return key
def browser():
 with sync_playwright() as p:
  b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-web-security'])
  for width in [320,390,768,1440]:
   page=b.new_page(viewport={'width':width,'height':950},accept_downloads=True)
   errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   html=(root/'compare.html').read_text().replace('<script type="module" src="compare.js"></script>','')
   page.set_content(html)
   page.add_style_tag(content=(root/'compare.css').read_text())
   mp={p:(root/p).read_text() for p in ['data/CABLES.json.json','data/CONDUCTOR_MATERIALS.json.json']}
   page.evaluate('''(fixture)=>{const d={'cable-thermal-custom-v1':JSON.stringify([fixture])};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>d[k]??null,setItem:(k,v)=>{d[k]=v},removeItem:k=>{delete d[k]}}})}''',json.loads(Path('/mnt/data/cts_gate_20261026/qa_candidate.json').read_text()))
   page.evaluate('''(files)=>{ window.fetch=async(url)=>{if(!(url in files)) throw Error('Unknown fixture '+url); return {json:async()=>JSON.parse(files[url])}} }''',mp)
   url=module(root/'compare.js')
   page.add_script_tag(type='importmap',content=json.dumps({'imports':imported}))
   page.add_script_tag(type='module',content='import '+repr(url)+';')
   try:
    page.wait_for_function('window.__ctsComparisonReady === true',timeout=12000)
    page.wait_for_function("document.querySelector('#catalogState').textContent.includes('source/custom records')",timeout=15000)
    actual=page.locator('#catalogState').inner_text();rows=page.locator('#candidateRows tr').count()
    overflow=page.evaluate('document.documentElement.scrollWidth-innerWidth')
    print(width,'ready',actual[:70],rows,'overflow',overflow,'jsErrors',errors[:3])
    if width==390:
     # source-basis ranking, must fail closed if missing construction
     page.locator('#candidateSearch').fill('CUSTOM-COMPARISON-QA')
     page.wait_for_timeout(200)
     page.locator('#candidateRows input').first.check()
     page.locator('#sharing_source').fill('QA candidate source, not physical verification')
     page.locator('#runRank').click();page.wait_for_timeout(300)
     print('RANKING',page.locator('#rankStatus').inner_text()[:240]);print('RANKROWS',page.locator('#rankRows tr').count(), 'TRIALS',page.locator('#trialRows tr').count());assert page.locator('#trialRows tr').count()==4
     assert 'feasible' in page.locator('#rankStatus').inner_text().lower()
     page.locator('button[data-mode="code"]').click();page.locator('#runCode').click()
     print('CODE (without sources)',page.locator('#codeStatus').inner_text()[:110]);assert page.locator('#codeStatus').get_attribute('data-status')=='INPUT REQUIRED'
     base=json.loads(Path('/mnt/data/cts_gate_20261026/reference_study.json').read_text())
     codevals={'code_name':'Synthetic code reference','edition':'Synthetic 2026','table':'QA table','row':'QA row','listing':'QA single-core','source':'Synthetic test, not adopted code','cable_id':base['cable_label'],'installation':'DIRECT BURIED','conductor_limit_c':'90','base_ampacity_a':'800','ambient_factor':'.9','grouping_factor':'.8','installation_factor':'.95','other_factor':'.975','conditions':'Synthetic conditions match only the reference study','factor_source':'Synthetic 4-factor QA case'}
     vendorvals={'manufacturer':'Synthetic maker','source':'Synthetic manufacturer fixture','cable_id':base['cable_label'],'published_a':'650','ambient_c':'25','max_temp_c':'90','soil_rho_km_w':'1','burial_depth_m':'3.08125','installation':'DIRECT BURIED','group_multiplier':'2.2377027288','tolerance_pct':'100'}
     for k,v in codevals.items():page.locator('#code_'+k).fill(str(v))
     for k,v in vendorvals.items():page.locator('#vendor_'+k).fill(str(v))
     page.locator('#code_conditions_verified').check();page.locator('#vendor_conditions_verified').check()
     page.locator('#runCode').click()
     print('CODE (matched sources)',page.locator('#codeStatus').inner_text()[:110],page.locator('#codeRows tr').count());assert page.locator('#codeRows tr').count()==3
     assert page.locator('#codeRows').inner_text().count('Yes')==3
     with page.expect_download(timeout=5000) as download:
      page.locator('#exportCode').click()
     print('DOWNLOADED',download.value.suggested_filename)
     assert download.value.suggested_filename=='code-ampacity-comparison.csv'
     page.locator('button[data-mode="rank"]').click();page.locator('#units').select_option('SI');print('SI',page.locator('#burial_depth_m').input_value());page.locator('#units').select_option('US');print('US',page.locator('#burial_depth_m').input_value())
     page.screenshot(path='/mnt/data/cts_gate_20261026/compare_mobile.png',full_page=True)
   except Exception as err:print('FAIL',width,str(err)[:1200],errors[:4]);raise
   finally:page.close()
  b.close()
if __name__=='__main__':browser()
